"""
MiniNExT
See README for details
"""
