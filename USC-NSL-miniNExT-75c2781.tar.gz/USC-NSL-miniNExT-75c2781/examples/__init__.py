"""
MiniNExT Examples
See README for details
"""
