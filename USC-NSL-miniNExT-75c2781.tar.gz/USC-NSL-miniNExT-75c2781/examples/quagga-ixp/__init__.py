"""
Quagga IXP Example for MiniNExT
"""
