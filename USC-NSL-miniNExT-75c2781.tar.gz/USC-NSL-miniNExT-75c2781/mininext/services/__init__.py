"""
MiniNExT Services
Preconfigured services for a variety of applications
"""
