"""
MiniNExT Enhancements and Extensions
See README for details
"""
